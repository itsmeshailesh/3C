#include<stdio.h>

int main()
{
    int num;
    printf("Enter the number : ");
    scanf("%d",&num);
    if(num<0)
        printf("NEGATIVE HAI BOSS");
    else
        printf("POSITIVE HAI");
    return 0;
}

