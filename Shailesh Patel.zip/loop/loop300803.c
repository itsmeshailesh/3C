//WAP to print alphabets from a to z using while loop
#include<stdio.h>
int main()
{
    int i;
    printf("Alphabets are : ");
    i=97;
    while(i<=122)
        {
            printf("\n%c",i++);
        }
    return 0;
}


