#include<stdio.h>
int main()
{
    int num,i=0;
    printf("Enter any number  : ");
    scanf(" %d",&num);
    if(num<0)
        i=-1;
    else
        if(num>1)

    switch(i)
    {
        case 1 :    printf("%d is Positive ",num);
                    break;
        case -1 :    printf("%d is Negative",num);
                    break;
        case 0 :    printf("ZERO");
                    break;

    }

    return 0;

}



