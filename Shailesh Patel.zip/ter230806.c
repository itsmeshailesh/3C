#include<stdio.h>
int main()
{
    int code;
    scanf("%d",&code);
    (code>1)?printf("\nJerusalem"):(code<1)?printf("\nEddie"):printf("\nC Brain");
    return 0;
}
