#ifndef ADD_H_INCLUDED
#define ADD_H_INCLUDED
int add(int,int);


#endif // ADD_H_INCLUDED
